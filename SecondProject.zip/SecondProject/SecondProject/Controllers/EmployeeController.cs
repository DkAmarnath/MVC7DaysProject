﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using SecondProject.Models;
using SecondProject.ViewModel;
using SecondProject.Filters;

namespace SecondProject.Controllers
{
    public class EmployeeController : Controller
    {
        // GET: Test
        public string getString()
        {
            return "Hello this is your first String output";
        }
         [Authorize]
        [HeaderFooterFilter]
        [Route("Employee/List")]
        public ActionResult Index()
        {
            //Employee e =new Employee();
            //e.FirstName = "Amarnath";
            //e.LastName="DK";
            //e.Salary=12333;

            //EmployeeViewModel EmpViewModel = new EmployeeViewModel();
            //EmpViewModel.EmployeeName = e.FirstName + " " + e.LastName;
            //EmpViewModel.Salary = e.Salary.ToString("C");
            //if(e.Salary>15000)
            //{
            //    EmpViewModel.SalaryColor = "yellow";

            //}
            //else
            //{
            //    EmpViewModel.SalaryColor = "green";
            //}
            ////ViewData["Employee"] = e;
            ////return View("MyView");
            ////ViewBag.Employee = e;
            //EmpViewModel.UserName = "Admin";
            //return View("MyView",EmpViewModel);
            EmployeeListViewModel employeelistviewmodel = new EmployeeListViewModel();
            EmployeeBusinessLayer empbal = new EmployeeBusinessLayer();
            List<Employee> emplist = empbal.GetEmployees();
            //List<EmployeeListViewModel> emplistmodel = new List<EmployeeListViewModel>();
            List<EmployeeViewModel> emplistmodel = new List<EmployeeViewModel>();
            foreach (Employee emp in emplist)
            {

                EmployeeViewModel empviewmodel = new EmployeeViewModel();
                empviewmodel.EmployeeName = emp.FirstName + " " + emp.LastName;
                empviewmodel.Salary = emp.Salary.ToString("C");
                if (emp.Salary > 15000)
                {
                    empviewmodel.SalaryColor = "yellow";
                }
                else
                {
                    empviewmodel.SalaryColor = "green";
                }
                emplistmodel.Add(empviewmodel);
            }
            employeelistviewmodel.Employees = emplistmodel;
            //employeelistviewmodel.UserName = User.Identity.Name;
            //employeelistviewmodel.FooterData = new FooterViewModel();
            //employeelistviewmodel.FooterData.CompanyName = "StepByStepSchools";//Can be set to dynamic value
            //employeelistviewmodel.FooterData.Year = DateTime.Now.Year.ToString();
            return View("Index", employeelistviewmodel);


        }
        [HeaderFooterFilter]
        [AdminFilter]
        public ActionResult AddNew()
        {
            try
            {
                CreateEmployeeViewModel employeeListViewModel = new CreateEmployeeViewModel();
                //employeeListViewModel.FooterData = new FooterViewModel();
                //employeeListViewModel.FooterData.CompanyName = "StepByStepSchools";//Can be set to dynamic value
                //employeeListViewModel.FooterData.Year = DateTime.Now.Year.ToString();
                //employeeListViewModel.UserName = User.Identity.Name; //New Line
                return View("CreateEmployee", employeeListViewModel);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        [AdminFilter]
        [HeaderFooterFilter]
        [ValidateAntiForgeryToken]
        public ActionResult SaveEmployee(Employee e, string BtnSubmit)
        {
            switch (BtnSubmit)
            {
                case "Save Employee":
                    if (ModelState.IsValid)
                    {
                        EmployeeBusinessLayer empBal = new EmployeeBusinessLayer();
                        empBal.SaveEmployee(e);
                        return RedirectToAction("Index");
                    }
                    else
                    {
                        CreateEmployeeViewModel vm = new CreateEmployeeViewModel();
                        vm.FirstName = e.FirstName;
                        vm.LastName = e.LastName;
                        //vm.FooterData = new FooterViewModel();
                        //vm.FooterData.CompanyName = "StepByStepSchools";//Can be set to dynamic value
                        //vm.FooterData.Year = DateTime.Now.Year.ToString();
                        //vm.UserName = User.Identity.Name; //New Line
                        if (e.Salary != 0)
                        {
                            vm.Salary = e.Salary.ToString();
                        }
                        else
                        {
                            vm.Salary = ModelState["Salary"].Value.AttemptedValue;
                        }
                        return View("CreateEmployee", vm); // Day 4 Change - Passing e here
                    }

                case "Cancel":
                    return RedirectToAction("Index");
            }
            return new EmptyResult();
        }
        [ChildActionOnly]
        public ActionResult GetAddNewLink()
        {
            if (Convert.ToBoolean(Session["IsAdmin"]))
            {
                return PartialView("AddNewLink");
            }
            else
            {
                return new EmptyResult();
            }
        }
    }
}